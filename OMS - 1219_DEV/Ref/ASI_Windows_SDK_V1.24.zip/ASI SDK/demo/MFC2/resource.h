//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by demo.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_DEMO_DIALOG                 102
#define IDR_MAINFRAME                   128
#define IDR_MENU_RBDOWN                 130
#define IDC_COMBO_CAMERAS               1000
#define IDC_BUTTON_SCAN                 1001
#define IDC_STATIC_WIDTH                1002
#define IDC_STATIC_HEIGHT               1003
#define IDC_BUTTON_OPEN                 1004
#define IDC_EDIT_STARTX                 1006
#define IDC_EDIT_STARTY                 1007
#define IDC_EDIT_WIDTH                  1008
#define IDC_EDIT_HEIGHT                 1009
#define IDC_BUTTON_SETFORMAT            1010
#define IDC_COMBO_IMGTYPE               1011
#define IDC_BUTTON_STARTPOS             1012
#define IDC_COMBO_BIN                   1013
#define IDC_BUTTON_Start                1014
#define IDC_BUTTON_stop                 1015
#define IDC_BUTTON_CLOSE                1016
#define IDC_COMBO_CTRL                  1017
#define IDC_SLIDER_CTRL                 1018
#define IDC_STATIC_MIN                  1019
#define IDC_STATIC_MAX                  1020
#define IDC_STATIC_POS                  1021
#define IDC_CHECK_TIME                  1023
#define IDC_STATIC_TEMP                 1024
#define IDC_BUTTON_NORTH                1025
#define IDC_BUTTON_SOUTH                1026
#define IDC_BUTTON_West                 1027
#define IDC_BUTTON_EAST                 1028
#define IDC_EDIT_DELAY                  1029
#define IDC_CHECK_AUTO                  1030
#define IDC_STATIC_CAMERATYPE           1031
#define IDC_CHECK_FLIPX                 1032
#define IDC_CHECK_FLIPY                 1033
#define IDC_BUTTON_AUTOTEST             1034
#define IDC_CHECK1                      1035
#define IDC_CHECK_SUBDARK               1035
#define IDC_BUTTON_GETLONGIMAGE         1036
#define IDC_SLIDER_CTRL0                1039
#define IDC_CHECK_CTRL0                 1041
#define IDC_EDIT_CTRL0                  1043
#define IDC_STATIC_CTRL0                1047
#define IDC_BUTTON_CLOSEALL             1071
#define IDC_BUTTON_STOPALL              1078
#define IDC_Test                        1079
#define IDC_STATIC_FPS                  1080
#define IDC_BUTTON_ABORTSNAP            1097
#define IDC_STATIC_SNAPTIME             1098
#define IDC_SCROLLBAR1                  1099
#define IDC_STATIC_CTRLPANEL            1100
#define IDC_BUTTON_READ_ID              1109
#define IDC_EDIT_ID_IN_SPI              1110
#define IDC_BUTTON_WRITE_ID             1111
#define IDC_BUTTON_ROI_SIZE             1112
#define IDC_BUTTON_MAX_SIZE             1113
#define IDC_CHECK2                      1114
#define IDC_CHECK_LOADHPC               1114
#define IDC_COMBO1                      1115
#define IDC_COMBO_SCALE                 1115
#define IDC_CHECK3                      1116
#define IDC_BUTTON_MODE                 1117
#define IDC_BUTTON_SEND_ST              1119
#define IDC_BUTTON_AUTO_TRIG            1120
#define IDC_EDIT_AUTO_TRIG_FPS          1121
#define IDC_COMBO_CAMMODE               1122
#define IDC_COMBO_TRIG_OUT_PIN          1123
#define IDC_COMBO_TRIG_OUT_LEVEL        1124
#define IDC_EDIT_TRIG_OUT_DELAY         1125
#define IDC_EDIT_TRIG_OUT_DURA          1126
#define IDC_STATIC_LEVEL                1127
#define IDC_STATIC_O_DELAY              1128
#define IDC_STATIC_O_DURA               1129
#define IDC_BUTTON_TO_SET               1130
#define IDC_BUTTON_TO_GET               1131
#define IDC_STATIC_PIN_NAME             1132
#define ID_MENU_SAVEIMAGEAS             32771
#define ID_MENU_SETFILEPATH             32772
#define ID_Menu                         32773
#define ID_MENU_SAVE                    32775

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        131
#define _APS_NEXT_COMMAND_VALUE         32779
#define _APS_NEXT_CONTROL_VALUE         1133
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
