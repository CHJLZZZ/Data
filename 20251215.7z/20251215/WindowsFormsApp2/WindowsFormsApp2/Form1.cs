﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Windows.Forms;
using BitMiracle.LibTiff.Classic;

namespace CsvToTiffConverter
{
    public partial class MainForm : Form
    {
        private string currentCsvPath = null;
        private ushort[,] imageData = null;

        private Button btnLoadCsv;
        private Button btnSaveTiff;
        private Label lblStatus;
        private TextBox txtFilePath;

        public MainForm()
        {
            InitializeComponent();
        }

        private void InitializeComponent()
        {
            this.Text = "CSV to 16-bit TIFF Converter";
            this.Size = new System.Drawing.Size(600, 250);
            this.StartPosition = FormStartPosition.CenterScreen;

            // Load CSV Button
            btnLoadCsv = new Button
            {
                Text = "載入 CSV",
                Location = new System.Drawing.Point(20, 20),
                Size = new System.Drawing.Size(120, 40),
                Font = new System.Drawing.Font("Microsoft JhengHei", 10F)
            };
            btnLoadCsv.Click += BtnLoadCsv_Click;

            // Save TIFF Button
            btnSaveTiff = new Button
            {
                Text = "存成 16-bit TIFF",
                Location = new System.Drawing.Point(160, 20),
                Size = new System.Drawing.Size(150, 40),
                Font = new System.Drawing.Font("Microsoft JhengHei", 10F),
                Enabled = false
            };
            btnSaveTiff.Click += BtnSaveTiff_Click;

            // File Path TextBox
            txtFilePath = new TextBox
            {
                Location = new System.Drawing.Point(20, 80),
                Size = new System.Drawing.Size(540, 25),
                ReadOnly = true,
                Font = new System.Drawing.Font("Consolas", 9F)
            };

            // Status Label
            lblStatus = new Label
            {
                Location = new System.Drawing.Point(20, 120),
                Size = new System.Drawing.Size(540, 80),
                Font = new System.Drawing.Font("Microsoft JhengHei", 9F),
                Text = "請先載入 CSV 檔案"
            };

            this.Controls.Add(btnLoadCsv);
            this.Controls.Add(btnSaveTiff);
            this.Controls.Add(txtFilePath);
            this.Controls.Add(lblStatus);
        }

        private void BtnLoadCsv_Click(object sender, EventArgs e)
        {
            using (OpenFileDialog dialog = new OpenFileDialog())
            {
                dialog.Filter = "CSV Files (*.csv)|*.csv|All Files (*.*)|*.*";
                dialog.Title = "選擇 CSV 檔案";

                if (dialog.ShowDialog() == DialogResult.OK)
                {
                    try
                    {
                        lblStatus.Text = "讀取中...";
                        Application.DoEvents();

                        currentCsvPath = dialog.FileName;
                        txtFilePath.Text = currentCsvPath;

                        imageData = CsvImageReader.ReadCsv(currentCsvPath);

                        int height = imageData.GetLength(0);
                        int width = imageData.GetLength(1);

                        lblStatus.Text = $"載入成功！\n影像尺寸：{width} x {height}\n數值範圍：{GetValueRange(imageData)}";
                        btnSaveTiff.Enabled = true;
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"載入失敗：{ex.Message}", "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        lblStatus.Text = "載入失敗";
                        btnSaveTiff.Enabled = false;
                    }
                }
            }
        }

        private void BtnSaveTiff_Click(object sender, EventArgs e)
        {
            if (imageData == null || string.IsNullOrEmpty(currentCsvPath))
            {
                MessageBox.Show("請先載入 CSV 檔案", "提示", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                lblStatus.Text = "儲存中...";
                Application.DoEvents();

                string outputPath = FileHelper.GetUniqueOutputPath(currentCsvPath, ".tif");
                TiffWriter.Write16BitTiff(outputPath, imageData);

                lblStatus.Text = $"儲存成功！\n檔案：{Path.GetFileName(outputPath)}\n路徑：{Path.GetDirectoryName(outputPath)}";
                MessageBox.Show($"成功儲存為：\n{outputPath}", "完成", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"儲存失敗：{ex.Message}", "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error);
                lblStatus.Text = "儲存失敗";
            }
        }

        private string GetValueRange(ushort[,] data)
        {
            ushort min = ushort.MaxValue;
            ushort max = ushort.MinValue;

            for (int i = 0; i < data.GetLength(0); i++)
            {
                for (int j = 0; j < data.GetLength(1); j++)
                {
                    if (data[i, j] < min) min = data[i, j];
                    if (data[i, j] > max) max = data[i, j];
                }
            }

            return $"{min} ~ {max}";
        }

        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new MainForm());
        }
    }

    // CSV 讀取類別
    public static class CsvImageReader
    {
        public static ushort[,] ReadCsv(string filePath)
        {
            if (!File.Exists(filePath))
                throw new FileNotFoundException("找不到檔案", filePath);

            List<ushort[]> rows = new List<ushort[]>();
            int expectedWidth = -1;

            using (StreamReader reader = new StreamReader(filePath))
            {
                string line;
                int lineNumber = 0;

                while ((line = reader.ReadLine()) != null)
                {
                    lineNumber++;

                    if (string.IsNullOrWhiteSpace(line))
                        continue;

                    string[] values = line.Split(',');

                    if (expectedWidth == -1)
                    {
                        expectedWidth = values.Length;
                    }
                    else if (values.Length != expectedWidth)
                    {
                        throw new InvalidDataException($"第 {lineNumber} 行的欄位數不一致（期望 {expectedWidth}，實際 {values.Length}）");
                    }

                    ushort[] row = new ushort[values.Length];
                    for (int i = 0; i < values.Length; i++)
                    {
                        if (!ushort.TryParse(values[i].Trim(), out row[i]))
                        {
                            throw new InvalidDataException($"第 {lineNumber} 行，第 {i + 1} 欄的數值無效：'{values[i]}'");
                        }
                    }

                    rows.Add(row);
                }
            }

            if (rows.Count == 0)
                throw new InvalidDataException("CSV 檔案是空的");

            int height = rows.Count;
            int width = rows[0].Length;
            ushort[,] imageData = new ushort[height, width];

            for (int i = 0; i < height; i++)
            {
                for (int j = 0; j < width; j++)
                {
                    imageData[i, j] = rows[i][j];
                }
            }

            return imageData;
        }
    }

    // TIFF 寫入類別
    public static class TiffWriter
    {
        public static void Write16BitTiff(string filePath, ushort[,] imageData)
        {
            int height = imageData.GetLength(0);
            int width = imageData.GetLength(1);

            using (Tiff output = Tiff.Open(filePath, "w"))
            {
                if (output == null)
                    throw new IOException($"無法建立 TIFF 檔案：{filePath}");

                // 設定 TIFF 標籤
                output.SetField(TiffTag.IMAGEWIDTH, width);
                output.SetField(TiffTag.IMAGELENGTH, height);
                output.SetField(TiffTag.SAMPLESPERPIXEL, 1);
                output.SetField(TiffTag.BITSPERSAMPLE, 16);
                output.SetField(TiffTag.ORIENTATION, BitMiracle.LibTiff.Classic.Orientation.TOPLEFT);
                output.SetField(TiffTag.PLANARCONFIG, PlanarConfig.CONTIG);
                output.SetField(TiffTag.PHOTOMETRIC, Photometric.MINISBLACK);
                output.SetField(TiffTag.COMPRESSION, Compression.NONE);
                output.SetField(TiffTag.ROWSPERSTRIP, height);

                // 轉換為 byte array (Little-Endian)
                byte[] buffer = new byte[width * 2];

                for (int row = 0; row < height; row++)
                {
                    for (int col = 0; col < width; col++)
                    {
                        ushort value = imageData[row, col];
                        buffer[col * 2] = (byte)(value & 0xFF);
                        buffer[col * 2 + 1] = (byte)((value >> 8) & 0xFF);
                    }

                    output.WriteScanline(buffer, row);
                }
            }
        }
    }

    // 檔案處理工具類別
    public static class FileHelper
    {
        public static string GetUniqueOutputPath(string csvPath, string newExtension)
        {
            string directory = Path.GetDirectoryName(csvPath);
            string fileNameWithoutExt = Path.GetFileNameWithoutExtension(csvPath);
            string outputPath = Path.Combine(directory, fileNameWithoutExt + newExtension);

            if (!File.Exists(outputPath))
                return outputPath;

            int counter = 1;
            while (true)
            {
                string newFileName = $"{fileNameWithoutExt}_{counter}{newExtension}";
                string newPath = Path.Combine(directory, newFileName);

                if (!File.Exists(newPath))
                    return newPath;

                counter++;

                if (counter > 9999)
                    throw new InvalidOperationException("無法產生唯一檔名（超過 9999 個重複檔案）");
            }
        }
    }
}