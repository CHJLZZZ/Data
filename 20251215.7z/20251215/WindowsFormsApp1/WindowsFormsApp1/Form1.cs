﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;
using BitMiracle.LibTiff.Classic;

namespace ProfilePeakDetector
{
    // Program entry point
    static class Program
    {
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form1());
        }
    }

    public class Form1 : Form
    {
        // 影像相關
        private Bitmap displayImage;
        private double[,] grayscaleImage;
        private const int bitDepth = 16;
        private const int maxGrayValue = 65535;
        private Rectangle roi = Rectangle.Empty;

        // 縮放平移
        private float zoomFactor = 1.0f;
        private Point panOffset = Point.Empty;
        private Point mouseDownPoint;
        private bool isPanning = false;

        // ROI框選 - 雙模式
        private enum ROIMode { FreeDraw, FixedSize }
        private ROIMode currentROIMode = ROIMode.FreeDraw;
        private bool isDrawingROI = false;
        private bool isSelectingCenter = false;
        private Point roiStartPoint;
        private Point currentMousePos = Point.Empty;

        // Peak檢測結果
        private List<int> peakPositions = new List<int>();
        private List<double> peakMaxValues = new List<double>();      // 最大灰階
        private List<double> peakAvgValues = new List<double>();      // 平均灰階
        private List<double> peakIntegralValues = new List<double>(); // 積分面積
        private double[] profile;

        // Peak統計模式
        private enum PeakStatMode { Maximum, Average, Integral }

        // 間距分析
        private List<double> peakSpacings = new List<double>();
        private List<bool> isAbnormalPeak = new List<bool>();
        private double averageSpacing = 0;

        // 奇偶和（用於計算和匯出，不顯示在UI）
        private double evenSum = 0;
        private double oddSum = 0;

        // UI控件
        private PictureBox pictureBox;
        private Chart chartProfile;
        private Button btnLoadImage;
        private Button btnSelectROI;
        private Button btnProcess;
        private Button btnExport;
        private TextBox txtMinHeight;
        private TextBox txtMinDistance;
        private TextBox txtSpacingTolerance;
        private TextBox txtFinalValue;
        private CheckBox chkShowPeaks;
        private CheckBox chkEnhanceContrast;
        private Label lblMinHeight;
        private Label lblMinDistance;
        private Label lblSpacingTolerance;
        private Label lblAverageSpacing;
        private Label lblAbnormalCount;
        private Label lblFinalValue;
        private RadioButton rbPeakMaximum;
        private RadioButton rbPeakAverage;
        private RadioButton rbPeakIntegral;

        // ROI模式相關UI
        private RadioButton rbFreeDraw;
        private RadioButton rbFixedSize;
        private TextBox txtROIWidth;
        private TextBox txtROIHeight;
        private Label lblROIWidth;
        private Label lblROIHeight;
        private Label lblROIInfo;

        public Form1()
        {
            InitializeComponents();
        }

        private void InitializeComponents()
        {
            // 設定表單屬性
            this.Text = "Profile Peak Detection Tool (16bit Only)";
            this.ClientSize = new Size(1400, 800);
            this.StartPosition = FormStartPosition.CenterScreen;

            // 左側面板
            Panel leftPanel = new Panel
            {
                Dock = DockStyle.Left,
                Width = 250,
                BackColor = Color.WhiteSmoke,
                Padding = new Padding(10),
                AutoScroll = true
            };

            int yPos = 10;

            // 按鈕1: 載入影像
            btnLoadImage = new Button
            {
                Text = "載入影像 (16bit)",
                Location = new Point(10, yPos),
                Size = new Size(230, 40),
                Font = new Font("Microsoft JhengHei", 10, FontStyle.Bold)
            };
            btnLoadImage.Click += BtnLoadImage_Click;
            leftPanel.Controls.Add(btnLoadImage);
            yPos += 50;

            // Checkbox: 強化對比
            chkEnhanceContrast = new CheckBox
            {
                Text = "強化對比",
                Location = new Point(10, yPos),
                Size = new Size(230, 25),
                Font = new Font("Microsoft JhengHei", 9),
                Checked = false
            };
            chkEnhanceContrast.CheckedChanged += ChkEnhanceContrast_CheckedChanged;
            leftPanel.Controls.Add(chkEnhanceContrast);
            yPos += 35;

            // === ROI選擇模式區塊 ===
            Label lblROIMode = new Label
            {
                Text = "ROI選擇模式:",
                Location = new Point(10, yPos),
                Size = new Size(230, 20),
                Font = new Font("Microsoft JhengHei", 9, FontStyle.Bold)
            };
            leftPanel.Controls.Add(lblROIMode);
            yPos += 25;

            // RadioButton: 自由拖曳
            rbFreeDraw = new RadioButton
            {
                Text = "自由拖曳",
                Location = new Point(10, yPos),
                Size = new Size(110, 25),
                Font = new Font("Microsoft JhengHei", 9),
                Checked = true
            };
            rbFreeDraw.CheckedChanged += RbROIMode_CheckedChanged;
            leftPanel.Controls.Add(rbFreeDraw);

            // RadioButton: 固定尺寸
            rbFixedSize = new RadioButton
            {
                Text = "固定尺寸",
                Location = new Point(130, yPos),
                Size = new Size(110, 25),
                Font = new Font("Microsoft JhengHei", 9),
                Checked = false
            };
            rbFixedSize.CheckedChanged += RbROIMode_CheckedChanged;
            leftPanel.Controls.Add(rbFixedSize);
            yPos += 30;

            // 固定尺寸輸入框 - 寬度
            lblROIWidth = new Label
            {
                Text = "ROI寬度:",
                Location = new Point(10, yPos),
                Size = new Size(80, 20),
                Font = new Font("Microsoft JhengHei", 9),
                Enabled = false
            };
            leftPanel.Controls.Add(lblROIWidth);

            txtROIWidth = new TextBox
            {
                Text = "100",
                Location = new Point(100, yPos),
                Size = new Size(140, 25),
                Enabled = false
            };
            leftPanel.Controls.Add(txtROIWidth);
            yPos += 30;

            // 固定尺寸輸入框 - 高度
            lblROIHeight = new Label
            {
                Text = "ROI高度:",
                Location = new Point(10, yPos),
                Size = new Size(80, 20),
                Font = new Font("Microsoft JhengHei", 9),
                Enabled = false
            };
            leftPanel.Controls.Add(lblROIHeight);

            txtROIHeight = new TextBox
            {
                Text = "100",
                Location = new Point(100, yPos),
                Size = new Size(140, 25),
                Enabled = false
            };
            leftPanel.Controls.Add(txtROIHeight);
            yPos += 35;

            // 按鈕2: 框選ROI
            btnSelectROI = new Button
            {
                Text = "框選ROI",
                Location = new Point(10, yPos),
                Size = new Size(230, 40),
                Font = new Font("Microsoft JhengHei", 10, FontStyle.Bold)
            };
            btnSelectROI.Click += BtnSelectROI_Click;
            leftPanel.Controls.Add(btnSelectROI);
            yPos += 50;

            // ROI資訊顯示
            lblROIInfo = new Label
            {
                Text = "ROI: 未設定",
                Location = new Point(10, yPos),
                Size = new Size(230, 40),
                Font = new Font("Microsoft JhengHei", 8),
                ForeColor = Color.DarkBlue,
                BackColor = Color.LightYellow,
                BorderStyle = BorderStyle.FixedSingle,
                TextAlign = ContentAlignment.MiddleCenter
            };
            leftPanel.Controls.Add(lblROIInfo);
            yPos += 50;

            // 最小高度門檻
            lblMinHeight = new Label
            {
                Text = "最小高度門檻 (0~65535):",
                Location = new Point(10, yPos),
                Size = new Size(230, 20),
                Font = new Font("Microsoft JhengHei", 9)
            };
            leftPanel.Controls.Add(lblMinHeight);
            yPos += 25;

            txtMinHeight = new TextBox
            {
                Text = "1000",
                Location = new Point(10, yPos),
                Size = new Size(230, 25)
            };
            leftPanel.Controls.Add(txtMinHeight);
            yPos += 35;

            // Peak最小距離
            lblMinDistance = new Label
            {
                Text = "Peak最小距離 (像素):",
                Location = new Point(10, yPos),
                Size = new Size(230, 20),
                Font = new Font("Microsoft JhengHei", 9)
            };
            leftPanel.Controls.Add(lblMinDistance);
            yPos += 25;

            txtMinDistance = new TextBox
            {
                Text = "3",
                Location = new Point(10, yPos),
                Size = new Size(230, 25)
            };
            leftPanel.Controls.Add(txtMinDistance);
            yPos += 35;

            // 間距容差
            lblSpacingTolerance = new Label
            {
                Text = "間距容差 (像素):",
                Location = new Point(10, yPos),
                Size = new Size(230, 20),
                Font = new Font("Microsoft JhengHei", 9)
            };
            leftPanel.Controls.Add(lblSpacingTolerance);
            yPos += 25;

            txtSpacingTolerance = new TextBox
            {
                Text = "2",
                Location = new Point(10, yPos),
                Size = new Size(230, 25)
            };
            leftPanel.Controls.Add(txtSpacingTolerance);
            yPos += 35;

            // === Peak統計模式區塊 ===
            Label lblPeakStatMode = new Label
            {
                Text = "Peak數值計算:",
                Location = new Point(10, yPos),
                Size = new Size(230, 20),
                Font = new Font("Microsoft JhengHei", 9, FontStyle.Bold)
            };
            leftPanel.Controls.Add(lblPeakStatMode);
            yPos += 25;

            rbPeakMaximum = new RadioButton
            {
                Text = "最大灰階",
                Location = new Point(10, yPos),
                Size = new Size(230, 25),
                Font = new Font("Microsoft JhengHei", 9),
                Checked = true
            };
            leftPanel.Controls.Add(rbPeakMaximum);
            yPos += 30;

            rbPeakAverage = new RadioButton
            {
                Text = "平均灰階",
                Location = new Point(10, yPos),
                Size = new Size(230, 25),
                Font = new Font("Microsoft JhengHei", 9),
                Checked = false
            };
            leftPanel.Controls.Add(rbPeakAverage);
            yPos += 30;

            rbPeakIntegral = new RadioButton
            {
                Text = "積分面積",
                Location = new Point(10, yPos),
                Size = new Size(230, 25),
                Font = new Font("Microsoft JhengHei", 9),
                Checked = false
            };
            leftPanel.Controls.Add(rbPeakIntegral);
            yPos += 35;

            // Checkbox: 顯示Peak位置
            chkShowPeaks = new CheckBox
            {
                Text = "在Profile圖上顯示Peak",
                Location = new Point(10, yPos),
                Size = new Size(230, 25),
                Font = new Font("Microsoft JhengHei", 9),
                Checked = false
            };
            chkShowPeaks.CheckedChanged += (s, e) => DisplayProfile();
            leftPanel.Controls.Add(chkShowPeaks);
            yPos += 35;

            // 按鈕3: 執行處理
            btnProcess = new Button
            {
                Text = "執行處理",
                Location = new Point(10, yPos),
                Size = new Size(230, 40),
                Font = new Font("Microsoft JhengHei", 10, FontStyle.Bold),
                BackColor = Color.LightGreen
            };
            btnProcess.Click += BtnProcess_Click;
            leftPanel.Controls.Add(btnProcess);
            yPos += 50;

            // 按鈕4: 匯出結果
            btnExport = new Button
            {
                Text = "匯出結果",
                Location = new Point(10, yPos),
                Size = new Size(230, 40),
                Font = new Font("Microsoft JhengHei", 10, FontStyle.Bold),
                BackColor = Color.LightBlue
            };
            btnExport.Click += BtnExport_Click;
            leftPanel.Controls.Add(btnExport);
            yPos += 60;

            // === 間距分析結果區塊 ===
            Label lblSpacingAnalysis = new Label
            {
                Text = "間距分析:",
                Location = new Point(10, yPos),
                Size = new Size(230, 20),
                Font = new Font("Microsoft JhengHei", 9, FontStyle.Bold),
                ForeColor = Color.DarkGreen
            };
            leftPanel.Controls.Add(lblSpacingAnalysis);
            yPos += 25;

            lblAverageSpacing = new Label
            {
                Text = "平均間距: --",
                Location = new Point(10, yPos),
                Size = new Size(230, 20),
                Font = new Font("Microsoft JhengHei", 8)
            };
            leftPanel.Controls.Add(lblAverageSpacing);
            yPos += 25;

            lblAbnormalCount = new Label
            {
                Text = "異常間距: --",
                Location = new Point(10, yPos),
                Size = new Size(230, 20),
                Font = new Font("Microsoft JhengHei", 8)
            };
            leftPanel.Controls.Add(lblAbnormalCount);
            yPos += 35;

            // 最終計算值
            lblFinalValue = new Label
            {
                Text = "最終計算值:",
                Location = new Point(10, yPos),
                Size = new Size(230, 20),
                Font = new Font("Microsoft JhengHei", 9)
            };
            leftPanel.Controls.Add(lblFinalValue);
            yPos += 25;

            txtFinalValue = new TextBox
            {
                Location = new Point(10, yPos),
                Size = new Size(230, 25),
                ReadOnly = true,
                BackColor = Color.White,
                Font = new Font("Microsoft JhengHei", 10, FontStyle.Bold)
            };
            leftPanel.Controls.Add(txtFinalValue);

            // 右側面板 - 使用 SplitContainer 分割影像和圖表
            SplitContainer splitContainer = new SplitContainer
            {
                Dock = DockStyle.Fill,
                Orientation = System.Windows.Forms.Orientation.Horizontal,
                SplitterDistance = 400,
                BorderStyle = BorderStyle.FixedSingle
            };

            // 影像顯示區 (上方) - 啟用雙緩衝
            pictureBox = new PictureBox
            {
                Dock = DockStyle.Fill,
                BackColor = Color.Black,
                SizeMode = PictureBoxSizeMode.Normal
            };

            // 啟用雙緩衝
            typeof(Control).GetProperty("DoubleBuffered",
                System.Reflection.BindingFlags.NonPublic |
                System.Reflection.BindingFlags.Instance)
                .SetValue(pictureBox, true, null);

            pictureBox.Paint += PictureBox_Paint;
            pictureBox.MouseWheel += PictureBox_MouseWheel;
            pictureBox.MouseDown += PictureBox_MouseDown;
            pictureBox.MouseMove += PictureBox_MouseMove;
            pictureBox.MouseUp += PictureBox_MouseUp;
            splitContainer.Panel1.Controls.Add(pictureBox);

            // Profile圖表 (下方)
            chartProfile = new Chart
            {
                Dock = DockStyle.Fill,
                BackColor = Color.White
            };

            ChartArea chartArea = new ChartArea("ProfileArea");
            chartArea.AxisX.Title = "Y Position";
            chartArea.AxisY.Title = "Average Intensity (16bit)";
            chartProfile.ChartAreas.Add(chartArea);

            Series series = new Series("Profile");
            series.ChartType = SeriesChartType.Line;
            series.Color = Color.Blue;
            series.BorderWidth = 2;
            chartProfile.Series.Add(series);

            // 正常Peak標記系列 (綠色)
            Series normalPeakSeries = new Series("NormalPeaks");
            normalPeakSeries.ChartType = SeriesChartType.Point;
            normalPeakSeries.Color = Color.Green;
            normalPeakSeries.MarkerStyle = MarkerStyle.Circle;
            normalPeakSeries.MarkerSize = 10;
            chartProfile.Series.Add(normalPeakSeries);

            // 異常Peak標記系列 (紅色)
            Series abnormalPeakSeries = new Series("AbnormalPeaks");
            abnormalPeakSeries.ChartType = SeriesChartType.Point;
            abnormalPeakSeries.Color = Color.Red;
            abnormalPeakSeries.MarkerStyle = MarkerStyle.Circle;
            abnormalPeakSeries.MarkerSize = 12;
            chartProfile.Series.Add(abnormalPeakSeries);

            splitContainer.Panel2.Controls.Add(chartProfile);

            // 加入主窗體
            this.Controls.Add(splitContainer);
            this.Controls.Add(leftPanel);
        }

        // 取得當前選擇的Peak統計模式
        private PeakStatMode GetSelectedPeakStatMode()
        {
            if (rbPeakMaximum.Checked) return PeakStatMode.Maximum;
            if (rbPeakAverage.Checked) return PeakStatMode.Average;
            if (rbPeakIntegral.Checked) return PeakStatMode.Integral;
            return PeakStatMode.Maximum;
        }

        // 根據選擇的模式取得Peak數值
        private List<double> GetSelectedPeakValues()
        {
            switch (GetSelectedPeakStatMode())
            {
                case PeakStatMode.Maximum:
                    return peakMaxValues;
                case PeakStatMode.Average:
                    return peakAvgValues;
                case PeakStatMode.Integral:
                    return peakIntegralValues;
                default:
                    return peakMaxValues;
            }
        }

        // ROI模式切換
        private void RbROIMode_CheckedChanged(object sender, EventArgs e)
        {
            if (rbFreeDraw.Checked)
            {
                currentROIMode = ROIMode.FreeDraw;
                txtROIWidth.Enabled = false;
                txtROIHeight.Enabled = false;
                lblROIWidth.Enabled = false;
                lblROIHeight.Enabled = false;
                btnSelectROI.Text = "框選ROI (拖曳)";
            }
            else if (rbFixedSize.Checked)
            {
                currentROIMode = ROIMode.FixedSize;
                txtROIWidth.Enabled = true;
                txtROIHeight.Enabled = true;
                lblROIWidth.Enabled = true;
                lblROIHeight.Enabled = true;
                btnSelectROI.Text = "框選ROI (點選中心)";
            }
        }

        // 更新ROI資訊顯示
        private void UpdateROIInfo()
        {
            if (roi.IsEmpty)
            {
                lblROIInfo.Text = "ROI: 未設定";
                lblROIInfo.BackColor = Color.LightYellow;
            }
            else
            {
                lblROIInfo.Text = $"ROI: X={roi.X}, Y={roi.Y}\nW={roi.Width}, H={roi.Height}";
                lblROIInfo.BackColor = Color.LightGreen;
            }
        }

        // 強化對比 CheckBox 改變事件
        private void ChkEnhanceContrast_CheckedChanged(object sender, EventArgs e)
        {
            if (grayscaleImage == null) return;

            // 重新生成顯示影像
            displayImage?.Dispose();
            displayImage = GrayscaleToDisplayBitmapFast(grayscaleImage, chkEnhanceContrast.Checked);
            pictureBox.Invalidate();
        }

        // 清除所有處理結果
        private void ClearResults()
        {
            profile = null;
            peakPositions.Clear();
            peakMaxValues.Clear();
            peakAvgValues.Clear();
            peakIntegralValues.Clear();
            peakSpacings.Clear();
            isAbnormalPeak.Clear();
            averageSpacing = 0;
            evenSum = 0;
            oddSum = 0;

            txtFinalValue.Text = "";

            lblAverageSpacing.Text = "平均間距: --";
            lblAbnormalCount.Text = "異常間距: --";

            chartProfile.Series["Profile"].Points.Clear();
            chartProfile.Series["NormalPeaks"].Points.Clear();
            chartProfile.Series["AbnormalPeaks"].Points.Clear();
        }

        // 載入影像
        private void BtnLoadImage_Click(object sender, EventArgs e)
        {
            using (OpenFileDialog ofd = new OpenFileDialog())
            {
                ofd.Filter = "16bit TIFF Files|*.tif;*.tiff|All Files|*.*";
                if (ofd.ShowDialog() == DialogResult.OK)
                {
                    try
                    {
                        // 使用 LibTiff 讀取真正的 16bit TIFF
                        grayscaleImage = LoadTiff16BitGrayscale(ofd.FileName);

                        // 快取顯示用 Bitmap（根據強化選項）
                        displayImage = GrayscaleToDisplayBitmapFast(grayscaleImage, chkEnhanceContrast.Checked);

                        // 重置顯示參數
                        zoomFactor = 1.0f;
                        panOffset = Point.Empty;
                        roi = Rectangle.Empty;
                        UpdateROIInfo();

                        // 清除處理結果
                        ClearResults();

                        pictureBox.Invalidate();

                        MessageBox.Show($"影像載入成功！\n尺寸: {grayscaleImage.GetLength(0)} x {grayscaleImage.GetLength(1)}\n位元深度: 16 bit\n灰階範圍: 0~65535",
                            "成功", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"載入影像失敗: {ex.Message}\n\n請確認影像為 16bit 灰階 TIFF 格式。", "錯誤",
                            MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }

        // 使用 LibTiff.NET 讀取 16bit 灰階 TIFF
        private double[,] LoadTiff16BitGrayscale(string filePath)
        {
            using (Tiff tiff = Tiff.Open(filePath, "r"))
            {
                if (tiff == null)
                {
                    throw new Exception("無法開啟 TIFF 檔案。");
                }

                // 讀取影像資訊
                int width = tiff.GetField(TiffTag.IMAGEWIDTH)[0].ToInt();
                int height = tiff.GetField(TiffTag.IMAGELENGTH)[0].ToInt();

                FieldValue[] bitsPerSampleValue = tiff.GetField(TiffTag.BITSPERSAMPLE);
                int bitsPerSample = bitsPerSampleValue != null ? bitsPerSampleValue[0].ToInt() : 8;

                FieldValue[] samplesPerPixelValue = tiff.GetField(TiffTag.SAMPLESPERPIXEL);
                int samplesPerPixel = samplesPerPixelValue != null ? samplesPerPixelValue[0].ToInt() : 1;

                // 檢查是否為 16bit 灰階
                if (bitsPerSample != 16 || samplesPerPixel != 1)
                {
                    throw new Exception($"不支援的格式！\n位元深度: {bitsPerSample} bit\n通道數: {samplesPerPixel}\n\n僅支援 16bit 單通道灰階影像。");
                }

                // 讀取影像數據
                double[,] grayscale = new double[width, height];
                int scanlineSize = tiff.ScanlineSize();
                byte[] buffer = new byte[scanlineSize];

                for (int y = 0; y < height; y++)
                {
                    tiff.ReadScanline(buffer, y);

                    for (int x = 0; x < width; x++)
                    {
                        // 16bit 灰階：2 bytes per pixel (Little Endian)
                        int offset = x * 2;
                        ushort value = (ushort)(buffer[offset] | (buffer[offset + 1] << 8));
                        grayscale[x, y] = value;
                    }
                }

                return grayscale;
            }
        }

        // 使用 LibTiff.NET 寫入 16bit 灰階 TIFF
        private void SaveTiff16BitGrayscale(string filePath, double[,] grayscale)
        {
            int width = grayscale.GetLength(0);
            int height = grayscale.GetLength(1);

            using (Tiff tiff = Tiff.Open(filePath, "w"))
            {
                if (tiff == null)
                {
                    throw new Exception("無法建立 TIFF 檔案。");
                }

                // 設定 TIFF 標籤
                tiff.SetField(TiffTag.IMAGEWIDTH, width);
                tiff.SetField(TiffTag.IMAGELENGTH, height);
                tiff.SetField(TiffTag.BITSPERSAMPLE, 16);
                tiff.SetField(TiffTag.SAMPLESPERPIXEL, 1);
                tiff.SetField(TiffTag.PHOTOMETRIC, Photometric.MINISBLACK);
                tiff.SetField(TiffTag.PLANARCONFIG, PlanarConfig.CONTIG);
                tiff.SetField(TiffTag.COMPRESSION, Compression.NONE);

                // 寫入影像數據
                byte[] buffer = new byte[width * 2];

                for (int y = 0; y < height; y++)
                {
                    for (int x = 0; x < width; x++)
                    {
                        ushort value = (ushort)Math.Max(0, Math.Min(65535, grayscale[x, y]));
                        int offset = x * 2;
                        buffer[offset] = (byte)(value & 0xFF);
                        buffer[offset + 1] = (byte)((value >> 8) & 0xFF);
                    }
                    tiff.WriteScanline(buffer, y);
                }
            }
        }

        // 使用 LockBits 快速轉換灰階為顯示用Bitmap
        private unsafe Bitmap GrayscaleToDisplayBitmapFast(double[,] grayscale, bool enhanceContrast = false)
        {
            int width = grayscale.GetLength(0);
            int height = grayscale.GetLength(1);
            Bitmap display = new Bitmap(width, height, PixelFormat.Format24bppRgb);

            double minVal = 0;
            double maxVal = maxGrayValue;

            // 如果啟用強化對比，找出實際的最小和最大值
            if (enhanceContrast)
            {
                minVal = double.MaxValue;
                maxVal = double.MinValue;

                for (int y = 0; y < height; y++)
                {
                    for (int x = 0; x < width; x++)
                    {
                        double val = grayscale[x, y];
                        if (val < minVal) minVal = val;
                        if (val > maxVal) maxVal = val;
                    }
                }

                // 避免除以零
                if (maxVal - minVal < 1.0)
                {
                    maxVal = minVal + 1.0;
                }
            }

            BitmapData bmpData = display.LockBits(
                new Rectangle(0, 0, width, height),
                ImageLockMode.WriteOnly,
                PixelFormat.Format24bppRgb);

            try
            {
                int stride = bmpData.Stride;
                byte* scan0 = (byte*)bmpData.Scan0;

                for (int y = 0; y < height; y++)
                {
                    byte* row = scan0 + (y * stride);
                    for (int x = 0; x < width; x++)
                    {
                        int displayGray;

                        if (enhanceContrast)
                        {
                            // 對比度拉伸：將 minVal~maxVal 映射到 0~255
                            displayGray = (int)((grayscale[x, y] - minVal) * 255.0 / (maxVal - minVal));
                        }
                        else
                        {
                            // 正規化到0~255顯示
                            displayGray = (int)(grayscale[x, y] * 255.0 / maxGrayValue);
                        }

                        displayGray = Math.Max(0, Math.Min(255, displayGray));

                        int offset = x * 3;
                        row[offset] = (byte)displayGray;     // B
                        row[offset + 1] = (byte)displayGray; // G
                        row[offset + 2] = (byte)displayGray; // R
                    }
                }
            }
            finally
            {
                display.UnlockBits(bmpData);
            }

            return display;
        }

        // 框選ROI
        private void BtnSelectROI_Click(object sender, EventArgs e)
        {
            if (grayscaleImage == null)
            {
                MessageBox.Show("請先載入影像！", "警告", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // 清除前一個ROI和處理結果
            roi = Rectangle.Empty;
            UpdateROIInfo();
            ClearResults();
            pictureBox.Invalidate();

            if (currentROIMode == ROIMode.FreeDraw)
            {
                isDrawingROI = true;
            }
            else // FixedSize
            {
                if (!int.TryParse(txtROIWidth.Text, out int roiW) ||
                    !int.TryParse(txtROIHeight.Text, out int roiH) ||
                    roiW <= 0 || roiH <= 0)
                {
                    MessageBox.Show("請輸入有效的ROI尺寸！", "警告",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                isSelectingCenter = true;
            }
        }

        // 執行處理
        private void BtnProcess_Click(object sender, EventArgs e)
        {
            if (grayscaleImage == null)
            {
                MessageBox.Show("請先載入影像！", "警告", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (roi.IsEmpty)
            {
                MessageBox.Show("請先框選ROI區域！", "警告", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (!double.TryParse(txtMinHeight.Text, out double minHeight) ||
                !int.TryParse(txtMinDistance.Text, out int minDistance) ||
                !double.TryParse(txtSpacingTolerance.Text, out double tolerance))
            {
                MessageBox.Show("參數輸入錯誤！", "警告", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                // 計算水平投影（水平方向累加 → 垂直Profile）
                profile = CalculateHorizontalProjection(grayscaleImage, roi);

                // 找出Peak點（位置）
                FindPeaks(profile, minHeight, minDistance);

                // 計算Peak區域統計值
                CalculatePeakRegionStatistics(profile);

                // 計算間距分析
                CalculateSpacingAnalysis(tolerance);

                // 計算奇偶和
                CalculateOddEvenSum();

                // 顯示Profile圖表
                DisplayProfile();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"處理失敗: {ex.Message}", "錯誤",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // 計算水平投影（水平方向累加 → 垂直Profile）
        private double[] CalculateHorizontalProjection(double[,] image, Rectangle region)
        {
            double[] projection = new double[region.Height];
            int width = image.GetLength(0);
            int height = image.GetLength(1);

            // 外層迴圈：遍歷Y方向（每一列）
            for (int y = 0; y < region.Height; y++)
            {
                double sum = 0;
                // 內層迴圈：水平方向累加 X
                for (int x = 0; x < region.Width; x++)
                {
                    int imgX = region.X + x;
                    int imgY = region.Y + y;

                    if (imgX >= 0 && imgX < width && imgY >= 0 && imgY < height)
                    {
                        sum += image[imgX, imgY];
                    }
                }
                projection[y] = sum / region.Width; // 除以寬度得到平均灰階值
            }

            return projection;
        }

        // 找出Peak點（位置）
        private void FindPeaks(double[] data, double minHeight, int minDistance)
        {
            peakPositions.Clear();

            List<int> candidates = new List<int>();

            // 找出所有local maximum
            for (int i = 1; i < data.Length - 1; i++)
            {
                if (data[i] > data[i - 1] && data[i] > data[i + 1] && data[i] >= minHeight)
                {
                    candidates.Add(i);
                }
            }

            // 套用最小距離限制
            if (candidates.Count > 0)
            {
                peakPositions.Add(candidates[0]);

                for (int i = 1; i < candidates.Count; i++)
                {
                    if (candidates[i] - peakPositions[peakPositions.Count - 1] >= minDistance)
                    {
                        peakPositions.Add(candidates[i]);
                    }
                }
            }
        }

        // 計算Peak區域統計值（波谷分割法）
        private void CalculatePeakRegionStatistics(double[] data)
        {
            peakMaxValues.Clear();
            peakAvgValues.Clear();
            peakIntegralValues.Clear();

            if (peakPositions.Count == 0)
                return;

            // 找出波谷位置
            List<int> valleyPositions = new List<int>();

            // 第一個波谷：0
            valleyPositions.Add(0);

            // 相鄰Peak之間的波谷
            for (int i = 0; i < peakPositions.Count - 1; i++)
            {
                int start = peakPositions[i];
                int end = peakPositions[i + 1];

                // 找出此區間的最小值位置
                int valleyPos = start;
                double minVal = data[start];

                for (int j = start + 1; j < end; j++)
                {
                    if (data[j] < minVal)
                    {
                        minVal = data[j];
                        valleyPos = j;
                    }
                }

                valleyPositions.Add(valleyPos);
            }

            // 最後一個波谷：data.Length - 1
            valleyPositions.Add(data.Length - 1);

            // 對每個Peak計算區域統計
            for (int i = 0; i < peakPositions.Count; i++)
            {
                int regionStart = valleyPositions[i];
                int regionEnd = valleyPositions[i + 1];
                int peakPos = peakPositions[i];

                // 計算區域統計值
                double maxVal = data[peakPos];
                double sum = 0;
                int count = 0;

                for (int j = regionStart; j <= regionEnd; j++)
                {
                    sum += data[j];
                    count++;
                }

                double avgVal = count > 0 ? sum / count : 0;
                double integralVal = sum;

                peakMaxValues.Add(maxVal);
                peakAvgValues.Add(avgVal);
                peakIntegralValues.Add(integralVal);
            }
        }

        // 計算間距分析
        private void CalculateSpacingAnalysis(double tolerance)
        {
            peakSpacings.Clear();
            isAbnormalPeak.Clear();
            averageSpacing = 0;

            if (peakPositions.Count < 2)
            {
                lblAverageSpacing.Text = "平均間距: --";
                lblAbnormalCount.Text = "異常間距: --";
                return;
            }

            // 步驟1: 計算相鄰距離
            for (int i = 1; i < peakPositions.Count; i++)
            {
                double spacing = peakPositions[i] - peakPositions[i - 1];
                peakSpacings.Add(spacing);
            }

            // 步驟2: 計算平均距離
            averageSpacing = peakSpacings.Average();

            // 步驟3: 判定異常（只看前一個間距）
            double lowerBound = averageSpacing - tolerance;
            double upperBound = averageSpacing + tolerance;

            isAbnormalPeak.Add(false); // 第一個Peak無前距，標記正常

            int abnormalCount = 0;

            for (int i = 0; i < peakSpacings.Count; i++)
            {
                double spacing = peakSpacings[i];
                bool isAbnormal = spacing < lowerBound || spacing > upperBound;
                isAbnormalPeak.Add(isAbnormal);

                if (isAbnormal)
                {
                    abnormalCount++;
                }
            }

            // 更新UI
            lblAverageSpacing.Text = $"平均間距: {averageSpacing:F2}";
            lblAbnormalCount.Text = $"異常間距: {abnormalCount}/{peakSpacings.Count}";
        }

        // 計算奇偶和
        private void CalculateOddEvenSum()
        {
            evenSum = 0;
            oddSum = 0;

            List<double> selectedValues = GetSelectedPeakValues();

            if (selectedValues.Count == 0)
            {
                txtFinalValue.Text = "0%";
                return;
            }

            // 計算配對數量
            int evenCount = (selectedValues.Count + 1) / 2;  // 偶數索引: 0,2,4...
            int oddCount = selectedValues.Count / 2;          // 奇數索引: 1,3,5...
            int pairCount = Math.Min(evenCount, oddCount);

            // 只取配對的Peak
            int totalUsed = pairCount * 2;

            for (int i = 0; i < totalUsed; i++)
            {
                if (i % 2 == 0)
                    evenSum += selectedValues[i];
                else
                    oddSum += selectedValues[i];
            }

            // 計算最終值（百分比）
            double maxSum = Math.Max(evenSum, oddSum);
            double finalValue = maxSum > 0 ? Math.Abs(evenSum - oddSum) / maxSum * 100.0 : 0;
            txtFinalValue.Text = finalValue.ToString("F2") + "%";
        }

        // 顯示Profile圖表
        private void DisplayProfile()
        {
            chartProfile.Series["Profile"].Points.Clear();
            chartProfile.Series["NormalPeaks"].Points.Clear();
            chartProfile.Series["AbnormalPeaks"].Points.Clear();

            if (profile != null)
            {
                // 找出 profile 的最大值
                double maxValue = profile.Max();

                // 設定 Y 軸範圍
                chartProfile.ChartAreas["ProfileArea"].AxisY.Minimum = 0;
                chartProfile.ChartAreas["ProfileArea"].AxisY.Maximum = maxValue * 1.1;

                for (int i = 0; i < profile.Length; i++)
                {
                    chartProfile.Series["Profile"].Points.AddXY(i, profile[i]);
                }

                // 如果checkbox勾選，顯示Peak位置（根據異常狀態分類）
                if (chkShowPeaks.Checked && peakPositions.Count > 0)
                {
                    List<double> selectedValues = GetSelectedPeakValues();

                    for (int i = 0; i < peakPositions.Count; i++)
                    {
                        int pos = peakPositions[i];
                        if (pos < profile.Length && i < selectedValues.Count)
                        {
                            // 使用選定的統計值作為顯示高度
                            double displayValue = selectedValues[i];

                            // 根據異常狀態選擇系列
                            if (i < isAbnormalPeak.Count && isAbnormalPeak[i])
                            {
                                chartProfile.Series["AbnormalPeaks"].Points.AddXY(pos, displayValue);
                            }
                            else
                            {
                                chartProfile.Series["NormalPeaks"].Points.AddXY(pos, displayValue);
                            }
                        }
                    }
                }
            }
        }

        // 匯出結果
        private void BtnExport_Click(object sender, EventArgs e)
        {
            if (profile == null || peakPositions.Count == 0)
            {
                MessageBox.Show("請先執行處理！", "警告", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            using (SaveFileDialog sfd = new SaveFileDialog())
            {
                sfd.Filter = "CSV Files|*.csv";
                sfd.FileName = "ProfileData";

                if (sfd.ShowDialog() == DialogResult.OK)
                {
                    try
                    {
                        string baseDir = Path.GetDirectoryName(sfd.FileName);
                        string baseName = Path.GetFileNameWithoutExtension(sfd.FileName);

                        // 1. 匯出Profile數據 (CSV)
                        string profilePath = sfd.FileName;
                        using (StreamWriter sw = new StreamWriter(profilePath))
                        {
                            sw.WriteLine("Y,Average_Intensity");
                            for (int i = 0; i < profile.Length; i++)
                            {
                                sw.WriteLine($"{i},{profile[i]:F2}");
                            }
                        }

                        // 2. 匯出計算結果 (TXT)
                        string resultPath = Path.Combine(baseDir, baseName + "_Results.txt");
                        using (StreamWriter sw = new StreamWriter(resultPath))
                        {
                            sw.WriteLine("=== Peak Detection Results ===");
                            sw.WriteLine($"Image Bit Depth: 16 bit");
                            sw.WriteLine($"Grayscale Range: 0~65535");
                            sw.WriteLine($"ROI: X={roi.X}, Y={roi.Y}, W={roi.Width}, H={roi.Height}");
                            sw.WriteLine();

                            sw.WriteLine("=== Peak Statistics ===");
                            sw.WriteLine($"Peak Count: {peakPositions.Count}");
                            sw.WriteLine($"Peak Positions: {string.Join(", ", peakPositions)}");
                            sw.WriteLine();

                            sw.WriteLine("Peak Detail (Position | Max | Avg | Integral):");
                            for (int i = 0; i < peakPositions.Count; i++)
                            {
                                sw.WriteLine($"  Peak[{i}]: Y={peakPositions[i]} | Max={peakMaxValues[i]:F2} | Avg={peakAvgValues[i]:F2} | Integral={peakIntegralValues[i]:F2}");
                            }
                            sw.WriteLine();

                            string selectedMode = GetSelectedPeakStatMode().ToString();
                            sw.WriteLine($"Selected Calculation Mode: {selectedMode}");
                            sw.WriteLine($"Even Sum: {evenSum:F2}");
                            sw.WriteLine($"Odd Sum: {oddSum:F2}");
                            sw.WriteLine($"Final Value: {txtFinalValue.Text}");
                            sw.WriteLine();

                            sw.WriteLine("=== Spacing Analysis ===");
                            sw.WriteLine($"Average Spacing: {averageSpacing:F2}");
                            sw.WriteLine($"Tolerance: ±{txtSpacingTolerance.Text}");

                            if (peakSpacings.Count > 0)
                            {
                                int abnormalCount = isAbnormalPeak.Count(x => x);
                                double regularity = (peakSpacings.Count - abnormalCount) * 100.0 / peakSpacings.Count;

                                sw.WriteLine($"Abnormal Count: {abnormalCount}/{peakSpacings.Count} ({100 - regularity:F1}%)");
                                sw.WriteLine($"Regularity Score: {regularity:F1}%");
                                sw.WriteLine();
                                sw.WriteLine("Spacing Details:");

                                for (int i = 0; i < peakSpacings.Count; i++)
                                {
                                    string status = isAbnormalPeak[i + 1] ? "ABNORMAL" : "Normal";
                                    sw.WriteLine($"  Peak[{i}]→Peak[{i + 1}]: {peakSpacings[i]:F2} [{status}]");
                                }

                                if (abnormalCount > 0)
                                {
                                    sw.WriteLine();
                                    sw.WriteLine("Abnormal Peak Details:");
                                    for (int i = 1; i < isAbnormalPeak.Count; i++)
                                    {
                                        if (isAbnormalPeak[i])
                                        {
                                            sw.WriteLine($"  Peak at Y={peakPositions[i]}: spacing={peakSpacings[i - 1]:F2} (expected: {averageSpacing - double.Parse(txtSpacingTolerance.Text):F2}~{averageSpacing + double.Parse(txtSpacingTolerance.Text):F2})");
                                        }
                                    }
                                }
                            }
                        }

                        // 3. 匯出ROI影像 (16bit TIFF)
                        string roiImagePath = Path.Combine(baseDir, baseName + "_ROI.tif");
                        double[,] roiImage = new double[roi.Width, roi.Height];

                        for (int y = 0; y < roi.Height; y++)
                        {
                            for (int x = 0; x < roi.Width; x++)
                            {
                                roiImage[x, y] = grayscaleImage[roi.X + x, roi.Y + y];
                            }
                        }

                        SaveTiff16BitGrayscale(roiImagePath, roiImage);

                        MessageBox.Show($"匯出成功！\n{profilePath}\n{resultPath}\n{roiImagePath}", "成功",
                            MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"匯出失敗: {ex.Message}", "錯誤",
                            MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }

        // PictureBox繪製
        private void PictureBox_Paint(object sender, PaintEventArgs e)
        {
            if (displayImage == null) return;

            Graphics g = e.Graphics;
            g.Clear(Color.Black);

            // 直接繪製快取的影像
            int drawWidth = (int)(displayImage.Width * zoomFactor);
            int drawHeight = (int)(displayImage.Height * zoomFactor);

            g.DrawImage(displayImage,
                panOffset.X, panOffset.Y,
                drawWidth, drawHeight);

            // 繪製ROI (確定的ROI用紅色實線)
            if (!roi.IsEmpty)
            {
                using (Pen pen = new Pen(Color.Red, 2))
                {
                    Rectangle scaledROI = new Rectangle(
                        (int)(roi.X * zoomFactor) + panOffset.X,
                        (int)(roi.Y * zoomFactor) + panOffset.Y,
                        (int)(roi.Width * zoomFactor),
                        (int)(roi.Height * zoomFactor)
                    );
                    g.DrawRectangle(pen, scaledROI);
                }
            }

            // 固定尺寸模式：繪製預覽方框 (黃色實線)
            if (isSelectingCenter && currentROIMode == ROIMode.FixedSize && !currentMousePos.IsEmpty)
            {
                if (int.TryParse(txtROIWidth.Text, out int roiW) &&
                    int.TryParse(txtROIHeight.Text, out int roiH))
                {
                    // 轉換為影像座標
                    int centerX = (int)((currentMousePos.X - panOffset.X) / zoomFactor);
                    int centerY = (int)((currentMousePos.Y - panOffset.Y) / zoomFactor);

                    // 計算預覽ROI
                    int previewX = centerX - roiW / 2;
                    int previewY = centerY - roiH / 2;

                    // 轉換回螢幕座標
                    Rectangle previewROI = new Rectangle(
                        (int)(previewX * zoomFactor) + panOffset.X,
                        (int)(previewY * zoomFactor) + panOffset.Y,
                        (int)(roiW * zoomFactor),
                        (int)(roiH * zoomFactor)
                    );

                    using (Pen pen = new Pen(Color.Yellow, 2))
                    {
                        g.DrawRectangle(pen, previewROI);
                    }
                }
            }
        }

        // 滑鼠滾輪縮放
        private void PictureBox_MouseWheel(object sender, MouseEventArgs e)
        {
            if (displayImage == null) return;

            float oldZoom = zoomFactor;

            if (e.Delta > 0)
                zoomFactor *= 1.2f;
            else
                zoomFactor /= 1.2f;

            zoomFactor = Math.Max(0.1f, Math.Min(zoomFactor, 10.0f));

            // 調整平移使縮放點在滑鼠位置
            panOffset.X = (int)(e.X - (e.X - panOffset.X) * zoomFactor / oldZoom);
            panOffset.Y = (int)(e.Y - (e.Y - panOffset.Y) * zoomFactor / oldZoom);

            pictureBox.Invalidate();
        }

        // 滑鼠按下
        private void PictureBox_MouseDown(object sender, MouseEventArgs e)
        {
            if (displayImage == null) return;

            if (e.Button == MouseButtons.Left)
            {
                if (isSelectingCenter)
                {
                    // 固定尺寸模式：點選中心
                    if (!int.TryParse(txtROIWidth.Text, out int roiW) ||
                        !int.TryParse(txtROIHeight.Text, out int roiH))
                        return;

                    // 轉換為影像座標
                    int centerX = (int)((e.X - panOffset.X) / zoomFactor);
                    int centerY = (int)((e.Y - panOffset.Y) / zoomFactor);

                    // 以點選位置為中心建立ROI
                    int x = centerX - roiW / 2;
                    int y = centerY - roiH / 2;

                    roi = new Rectangle(x, y, roiW, roiH);

                    // 限制ROI在影像範圍內
                    int imgWidth = grayscaleImage.GetLength(0);
                    int imgHeight = grayscaleImage.GetLength(1);

                    roi.X = Math.Max(0, Math.Min(roi.X, imgWidth - roiW));
                    roi.Y = Math.Max(0, Math.Min(roi.Y, imgHeight - roiH));
                    roi.Width = Math.Min(roiW, imgWidth - roi.X);
                    roi.Height = Math.Min(roiH, imgHeight - roi.Y);

                    isSelectingCenter = false;
                    UpdateROIInfo();
                    pictureBox.Invalidate();
                }
                else if (isDrawingROI)
                {
                    // 自由拖曳模式：開始拖曳
                    roiStartPoint = new Point(
                        (int)((e.X - panOffset.X) / zoomFactor),
                        (int)((e.Y - panOffset.Y) / zoomFactor)
                    );
                }
                else
                {
                    // 平移模式
                    isPanning = true;
                    mouseDownPoint = e.Location;
                }
            }
        }

        // 滑鼠移動
        private void PictureBox_MouseMove(object sender, MouseEventArgs e)
        {
            if (displayImage == null) return;

            // 更新滑鼠位置（用於繪製預覽框）
            currentMousePos = e.Location;

            // 固定尺寸模式：重繪預覽框
            if (isSelectingCenter && currentROIMode == ROIMode.FixedSize)
            {
                pictureBox.Invalidate();
                return;
            }

            if (isDrawingROI && e.Button == MouseButtons.Left)
            {
                // 更新ROI
                Point currentPoint = new Point(
                    (int)((e.X - panOffset.X) / zoomFactor),
                    (int)((e.Y - panOffset.Y) / zoomFactor)
                );

                int x = Math.Min(roiStartPoint.X, currentPoint.X);
                int y = Math.Min(roiStartPoint.Y, currentPoint.Y);
                int width = Math.Abs(currentPoint.X - roiStartPoint.X);
                int height = Math.Abs(currentPoint.Y - roiStartPoint.Y);

                roi = new Rectangle(x, y, width, height);
                pictureBox.Invalidate();
            }
            else if (isPanning && e.Button == MouseButtons.Left)
            {
                // 平移
                panOffset.X += e.X - mouseDownPoint.X;
                panOffset.Y += e.Y - mouseDownPoint.Y;
                mouseDownPoint = e.Location;
                pictureBox.Invalidate();
            }
        }

        // 滑鼠放開
        private void PictureBox_MouseUp(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                if (isDrawingROI)
                {
                    isDrawingROI = false;

                    // 限制ROI在影像範圍內
                    if (grayscaleImage != null)
                    {
                        int imgWidth = grayscaleImage.GetLength(0);
                        int imgHeight = grayscaleImage.GetLength(1);

                        roi.X = Math.Max(0, Math.Min(roi.X, imgWidth - 1));
                        roi.Y = Math.Max(0, Math.Min(roi.Y, imgHeight - 1));
                        roi.Width = Math.Min(roi.Width, imgWidth - roi.X);
                        roi.Height = Math.Min(roi.Height, imgHeight - roi.Y);
                    }

                    UpdateROIInfo();
                }

                isPanning = false;
            }
        }
    }
}